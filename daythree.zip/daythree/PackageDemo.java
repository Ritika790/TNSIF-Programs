package com.tns.daythree;

public class PackageDemo {

	public void show()
	{
		System.out.println("The class is defined outside the package");
	}
	
}
